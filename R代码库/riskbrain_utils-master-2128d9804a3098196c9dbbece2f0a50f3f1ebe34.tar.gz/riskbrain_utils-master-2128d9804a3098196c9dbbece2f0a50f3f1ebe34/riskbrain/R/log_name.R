#' @import utils
log_name <- function(env) {
    name <- getPackageName(env)
    if (name == '.GlobalEnv') {
        name <- 'riskbrain'
    }
    name
}
