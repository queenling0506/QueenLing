RiskbrainException <- function(code, message, error = NULL) {
    if (is.null(error)) {
        error <- list(code = code,
                      msg = message,
                      message = as.character(message),
                      call = NULL)
        class(error) <- c("RiskbrainException",
                          "simpleError",
                          "error",
                          "condition")
    } else {
        error$code <- code
        error$msg  <- message
        class(error) <- c("RiskbrainException", class(error))
    }

    error
}

is.RiskbrainException <- function(obj) {
    inherits(obj, 'RiskbrainException')
}
