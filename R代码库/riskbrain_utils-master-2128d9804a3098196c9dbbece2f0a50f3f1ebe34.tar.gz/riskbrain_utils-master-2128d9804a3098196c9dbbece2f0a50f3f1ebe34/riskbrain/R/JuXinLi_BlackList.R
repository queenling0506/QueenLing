JuXinLi_BlackList <- function(uuid, id_unqf) {
  # Call DP_interface_call to retrieve data from DP interface.
  # Notice: It's a must to handling with any possible errors
  res <- tryCatch(
    DP_interface_call(uuid, id_unqf, service.code = 'JuXinLi_BlackList'),
    error = function(err) {
      RiskbrainException(code = "",
                         message = conditionMessage(err),
                         error = err)
    }
  )

  # if error, throw it directly
  if (is.RiskbrainException(res)) stop(res)

  # if no error but wrong returned value
  if (res$code != 200L) {
    error <- RiskbrainException(code = res$code,
                                message = res$message)
    stop(error)
  }

  # everything is ok
  # res
  tables <- res$data$content

  lapply(tables, function(.table) {
    if (is.null(names(.table))) {
      .table <- lapply(.table, function(.row) {
        .row <- lapply(.row, function(.field) {
          ifelse(is.null(.field), NA, .field)
        })
        as.data.frame(.row, stringsAsFactors = FALSE)
      })

      do.call(rbind, .table)
    } else {
      .table <- lapply(.table, function(.field) {
        ifelse(is.null(.field), NA, .field)
      })

      as.data.frame(.table, stringsAsFactors = FALSE)
    }
  })
}
