# Logger's Environment
log.env <- new.env(parent = environment())

# Logger Initialization
log.init <- function(logger, env = parent.frame(n = 2)) {
    if (!exists(logger, log.env)) {
        logger.err <- paste0(env$logger, '.err')
        logger.layout <-
        futile.logger::layout.format('~t ~l  ~n:~f  ~m')
        futile.logger::flog.layout(logger.layout, name = logger)
        futile.logger::flog.layout(logger.layout, name = logger.err)
        futile.logger::flog.threshold(futile.logger::INFO, name = logger)
        futile.logger::flog.threshold(futile.logger::ERROR, name = logger.err)
        log.path <- '/home/finance/Logs/riskbrain.msxf.lo/'
        if (!dir.exists(log.path)) {
            log.path <- './'
        }

        infofile <- paste0(logger, '-info.log')
        errofile <- paste0(logger, '-err.log')

        log_file <- function() {
            # date <- strftime(Sys.Date(), format = "%Y%m%d")
            info.appender <-
                futile.logger::appender.file(paste0(log.path, infofile))
            err.appender <-
                futile.logger::appender.file(paste0(log.path, errofile))
            futile.logger::flog.appender(info.appender, name = logger)
            futile.logger::flog.appender(err.appender, name = logger.err)
        }


        log.info <- function(msg, ...) {
            log_file()
            futile.logger::flog.info(msg, ..., name = logger)
            invisible()
        }

        log.error <- function(msg, ...) {
            log_file()
            futile.logger::flog.error(msg, ..., name = logger.err)
            invisible()
        }
        log.env[[logger]] <- list(log.info = log.info,
                                  log.error = log.error)
    }

    invisible()
}

#' @title Logger Utility Function
#' @rdname logger
#'
#' @export
logger.info <- function(msg = NULL, ..., env = parent.frame()) {
    logger <- log_name(env)
    if (!exists(logger, envir = log.env)) {
        log.init(logger)
    }

    if (is.null(msg)) {
        return(log.env[[logger]]$log.info)
    }
    log.env[[logger]]$log.info(msg, ...)
}

#' @rdname logger
#' @export
logger.error <- function(msg = NULL, ..., env = parent.frame()) {
    logger <- log_name(env)
    if (!exists(logger, envir = log.env)) {
        log.init(logger)
    }

    if (is.null(msg)) {
        return(log.env[[logger]]$log.error)
    }
    log.env[[logger]]$log.error(msg, ...)
}
