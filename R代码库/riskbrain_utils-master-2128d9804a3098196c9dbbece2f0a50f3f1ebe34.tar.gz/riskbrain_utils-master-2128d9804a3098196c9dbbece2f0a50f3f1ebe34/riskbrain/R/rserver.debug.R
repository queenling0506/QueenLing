#' Debug Status of R Server
#'
#' @description \code{rserver.debug} checks the status of R Server system. If
#' R server is from a testing environment, the result will be \code{TRUE},
#' otherwise will be \code{FALSE}.
#'
#' @param env specify in which environment it can get the status of R server.
#' @return \code{TRUE} if a machine is for testing otherwise \code{FALSE}. By
#' default \code{TRUE}.
#'
#' @export
rserver.debug <- function(env = .GlobalEnv) {
    .debug <- TRUE

    if (exists('DEBUG', envir = env)) {
        .debug = as.logical(get('DEBUG', envir = env))
    }

    if (is.na(.debug)) {
        warning('DEBUG in .GlobalEnv cannot be coerced to logical.')
    }

    .debug
}
