VCE_Call = function(UUID, idUnqf, dataSourceCode, .debug = rserver.debug()) {
    #dataSourceCode: pboc1,pboc2_blaze,pboc3,JUXINLI_BLACK_LIST
    dataSourceCode <- dataSourceCode
    # Whether testing calls
    # for testing environment
    url.test <- 'http://10.250.20.216:8080/service/vce'

    # for production environment
    url.prod <- 'http://varquery.msxf.lo/vce'

    # preparation of header
    header <- c("Content-Type" = "application/json")
    url <- ifelse(.debug, url.test, url.prod)

    UUID <- stringr::str_replace_all(UUID, '-', '')

    # request body
    body <- list(queryKey = dataSourceCode,
                bizKey = idUnqf)

    jsonbody <- rjson::toJSON(body)
    jsonbody_utf8 <- enc2utf8(jsonbody)

    ## Dealing with connection error

    result <-  rjson::fromJSON(RCurl::postForm(
        uri = url,
        .opts = list(httpheader = header, postfields = jsonbody_utf8)
    ))

    ## return
    result

}
