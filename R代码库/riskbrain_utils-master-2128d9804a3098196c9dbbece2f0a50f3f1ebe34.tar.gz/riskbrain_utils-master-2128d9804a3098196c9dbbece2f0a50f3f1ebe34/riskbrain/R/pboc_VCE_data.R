pboc1 <- function(uuid, id_unqf) {
    # Call VCE_call to retrieve data from VCE interface.
    # Notice: It's a must to handling with any possible errors
    res <- tryCatch(
        VCE_Call(uuid, id_unqf, "pboc1"),
        error = function(err) {
            RiskbrainException(code = "",
                               message = conditionMessage(err),
                               error = err)
        }
    )

    # if error, throw it directly
    if (is.RiskbrainException(res))
        stop(res)

    # if no error but wrong returned value
    if (res$code != 200L) {
        error <- RiskbrainException(code = res$code,
                                    message = res$message)
        stop(error)
    }
    # everything is ok
    # res
    VCE_result <-
        as.data.frame(res$data$pboc1$PBOC1, stringsAsFactors = FALSE)

    VCE_result

}

pboc2 <- function(uuid, id_unqf) {
    # Call VCE_call to retrieve data from VCE interface.
    # Notice: It's a must to handling with any possible errors
    res <- tryCatch(
        VCE_Call(uuid, id_unqf, "pboc2_blaze"),
        error = function(err) {
            RiskbrainException(code = "",
                               message = conditionMessage(err),
                               error = err)
        }
    )

    # if error, throw it directly
    if (is.RiskbrainException(res))
        stop(res)

    # if no error but wrong returned value
    if (res$code != 200L) {
        error <- RiskbrainException(code = res$code,
                                    message = res$message)
        stop(error)
    }

    # everything is ok
    # res
    VCE_result_raw <- res$data$pboc2_blaze
    #get the sublist and cbind
    #pboc2_lsd_blaze,pboc2_blaze_lld,pboc2_int_blaze,pboc2_pbi_blaze,pboc2_lld_blaze
    # pboc2_lsd_blaze <- lapply(VCE_result_raw$pboc2_lsd_blaze,
    #                           function(.field) {
    #                               ifelse(is.null(.field), NA, .field)
    #                           })
    # pboc2_blaze_lld <- lapply(VCE_result_raw$pboc2_blaze_lld,
    #
    #                           function(.field) {
    #                               ifelse(is.null(.field), NA, .field)
    #                           })
    # pboc2_int_blaze <- lapply(VCE_result_raw$pboc2_int_blaze,
    #                           function(.field) {
    #                               ifelse(is.null(.field), NA, .field)
    #                           })
    # pboc2_pbi_blaze <- lapply(VCE_result_raw$pboc2_pbi_blaze,
    #                           function(.field) {
    #                               ifelse(is.null(.field), NA, .field)
    #                           })
    # pboc2_lcd_blaze <- lapply(VCE_result_raw$pboc2_lcd_blaze,
    #                           function(.field) {
    #                               ifelse(is.null(.field), NA, .field)
    #                           })
    #
    # VCE_result <-
    #     cbind(
    #         as.data.frame(pboc2_lsd_blaze, stringsAsFactors = FALSE),
    #         as.data.frame(pboc2_blaze_lld, stringsAsFactors = FALSE),
    #         as.data.frame(pboc2_int_blaze, stringsAsFactors = FALSE),
    #         as.data.frame(pboc2_pbi_blaze, stringsAsFactors = FALSE),
    #         as.data.frame(pboc2_lcd_blaze, stringsAsFactors = FALSE)
    #     )
    lapply(VCE_result_raw, function(.table) {
        .table <- lapply(.table, function(.field) {
            ifelse(is.null(.field), NA, .field)
        })

        as.data.frame(.table, stringsAsFactors = FALSE)
    })

    # VCE_result_raw
}

pboc3 <- function(uuid, id_unqf) {
    # Call VCE_call to retrieve data from VCE interface.
    # Notice: It's a must to handling with any possible errors
    res <- tryCatch(
        VCE_Call(uuid, id_unqf, "pboc3"),
        error = function(err) {
            RiskbrainException(code = "",
                               message = conditionMessage(err),
                               error = err)
        }
    )

    # if error, throw it directly
    if (is.RiskbrainException(res))
        stop(res)

    # if no error but wrong returned value
    if (res$code != 200L) {
        error <- RiskbrainException(code = res$code,
                                    message = res$message)
        stop(error)
    }

    # everything is ok
    # res
    VCE_result <-
        as.data.frame(res$data$pboc3$PBOC3, stringsAsFactors = FALSE)

    VCE_result
}
