EDS.Call = function(UUID, idUnqf, service.code,
    channel = '000', product.code = '0000',
    bus.name = 'Cash_Loan', .debug = TRUE){

    # Whether testing calls
    # for testing environment
    url.test = 'http://dataservice.msxf.lodev/resource'
    app.code.test = 'DataServiceTest'
    access.key.test = '8346BD26295057D8'
    # for production environment
    url.prod = 'http://dataservice.msxf.lo/resource'
    app.code.prod = 'R_development'
    access.key.prod = '8F5A38D3FBB73C6A'

    # preparation of header
    header = c("Content-Type" = "application/json")
    url = ifelse(.debug, url.test, url.prod)
    app.code = ifelse(.debug, app.code.test, app.code.prod)
    access.key = ifelse(.debug, access.key.test, access.key.prod)

    UUID = stringr::str_replace_all(UUID, '-', '')

    # request body
    body = list(service_code = service.code,
                app_code = app.code,
                access_key = access.key,
                channel = channel,
                bus_code = product.code,
                bus_name = bus.name,
                call_no = UUID,
                business_no = "",
                business_no_type = "001",
                service_param = list(idUnqf = idUnqf,
                                     period = 24))

    jsonbody <- rjson::toJSON(body)
    jsonbody_utf8 <- enc2utf8(jsonbody)

    ## Dealing with connection error
    n = 0
    while (n < 3) {
        n = n + 1
        result = tryCatch(
            RCurl::postForm(
                uri = url,
                .opts = list(httpheader = header,
                    postfields = jsonbody_utf8)
            ),
            error = function(err) {
                err
            }
        )
        ## An error occurs: connection reason
        if ('condition' %in% class(result) & n == 3) {
            stop(conditionMessage(result))
        }
        ## No error
        if (!'condition' %in% class(result)) {
            result = tryCatch(
                rjson::fromJSON(result),
                error = function(err) {
                    if (n == 3) {
                        stop(conditionMessage(result))
                    }
                }
            )
            if (is.list(result)) {
                if (result$code == 200) return(result)
                if (n == 3) stop(sprintf('Server Error: return code %s',
                    result$code))
            } else if (n == 3) stop('EDS Call Error')
        }

    }
}
