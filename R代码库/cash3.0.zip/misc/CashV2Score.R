library(dplyr)
library(xgboost)

#' cash.score.v2
#'
#' @param x a data.frame which is described in another document
#' @return score a real number between 0 and 1, indicating the likelihood of being a bad client. -1 represents score not available.

load("misc/cash_v2.rda")
cash.score.v2 <- function(X) {
    # some data cleansing work
    outlier.na <- function(x, min = 0, max = 999999900) {
        x <- as.numeric(x)
        ifelse(!is.na(x) & x >= min & x < max, x, NA)
    }

    X <- mutate(
        X,
        add_corlng = outlier.na(add_corlng, 73, 136),
        add_corltt = outlier.na(add_corltt, 3, 54),
        add_hjlng = outlier.na(add_hjlng, 73, 136),
        add_hjltt = outlier.na(add_hjltt, 3, 54),
        amtc_1lula120 = outlier.na(amtc_1lula120),
        amtc_1m6la030 = outlier.na(amtc_1m6la030),
        amtc_1mapa060 = outlier.na(amtc_1mapa060),
        amtc_1sapa060 = outlier.na(amtc_1sapa060),
        amtc_1scla120 = outlier.na(amtc_1scla120),
        amtc_1srpa060 = outlier.na(amtc_1srpa060),
        amtc_1ssla060 = outlier.na(amtc_1ssla060),
        amtc_acttpd = outlier.na(amtc_acttpd),
        amtc_htpdever = outlier.na(amtc_htpdever, max = Inf),
        amtc_utlcop = outlier.na(amtc_utlcop),
        amtl_1mprw03woww = outlier.na(amtl_1mprw03woww),
        amtl_apos6m = outlier.na(amtl_apos6m, max = Inf),
        amtl_inactlpd = outlier.na(amtl_inactlpd),
        amtl_os = outlier.na(amtl_os, max = Inf),
        v_diploma_D = ifelse(is.na(diploma), 0,
            ifelse(diploma == "大学本科（简称\"大学\"）" | diploma == "研究生", 1, 0)),
        gender_cd_1 = ifelse(is.na(gender_cd) | gender_cd == '1', 1, 0),
        jion_life_insure_1 = ifelse(!is.na(jion_life_insure) & jion_life_insure == '1', 1, 0),
        mo_earn = outlier.na(mo_earn, max = Inf),
        num_empc2y = outlier.na(num_empc2y, max = 5),
        numc_1mr6awww = outlier.na(numc_1mr6awww),
        numc_1scca031 = outlier.na(numc_1scca031),
        numc_1scca240 = outlier.na(numc_1scca240),
        numc_1sccw030 = outlier.na(numc_1sccw030),
        numc_1sccw120 = outlier.na(numc_1sccw120),
        numc_lpop = outlier.na(numc_lpop, max = 50),
        numc_pdm = outlier.na(numc_pdm, max = Inf),
        numi_3m = outlier.na(numi_3m, max = Inf),
        numi_acctm2y = outlier.na(numi_acctm2y, max = Inf),
        numi_rh3m = outlier.na(numi_rh3m, max = Inf),
        numi_self1m = outlier.na(numi_self1m, max = Inf),
        numi_wq2y = outlier.na(numi_wq2y, max = Inf),
        numl_1caca030www = outlier.na(numl_1caca030www),
        numl_1caca031www = outlier.na(numl_1caca031www),
        numl_1cacw06woww = outlier.na(numl_1cacw06woww),
        numl_1mpla03wwww = outlier.na(numl_1mpla03wwww),
        numl_1mplw03wwww = outlier.na(numl_1mplw03wwww),
        numl_1mplw06wwww = outlier.na(numl_1mplw06wwww),
        numl_1mplw12wwww = outlier.na(numl_1mplw12wwww),
        numl_1spdw06wwww = outlier.na(numl_1spdw06wwww),
        numl_1spdw12wwww = outlier.na(numl_1spdw12wwww),
        numl_3ltmtiw = outlier.na(numl_3ltmtiw),
        numl_3mtmtiw = outlier.na(numl_3mtmtiw),
        numl_emtglrrp = outlier.na(numl_emtglrrp, max = 9000),
        numl_inactemtglpdm = outlier.na(numl_inactemtglpdm, max = 9000),
        numl_lrrp = outlier.na(numl_lrrp, max = 9000),
        numl_os = outlier.na(numl_os, max = Inf),
        numl_others = outlier.na(numl_others, max = Inf),
        numl_pd = outlier.na(numl_pd, max = Inf),
        nums_acctpd3p = outlier.na(nums_acctpd3p, max = Inf),
        oth_earn = outlier.na(oth_earn, max = Inf),
        oth_loan = outlier.na(oth_loan, max = Inf),
        pbc1_peinum_emp2y = outlier.na(pbc1_peinum_emp2y),
        pbc1_pidnum_lcs6m = outlier.na(pbc1_pidnum_lcs6m),
        pbc1_plitimes_2y = outlier.na(pbc1_plitimes_2y),
        ratc_actrp = outlier.na(ratc_actrp),
        rtoc_1m6ca030 = outlier.na(rtoc_1m6ca030),
        rtoc_1mmca000 = outlier.na(rtoc_1mmca000),
        rtoc_1muca000 = outlier.na(rtoc_1muca000),
        timel_fsti = outlier.na(timel_fsti, max = Inf),
        timec_fsti = outlier.na(timec_fsti, max = Inf),
        times_fsti = outlier.na(times_fsti, max = Inf),
        time_credit = pmax(timel_fsti, timec_fsti, times_fsti, na.rm = TRUE),
        varsmaxcdiffreptmandisstmineffect = outlier.na(varsmaxcdiffreptmandisstmineffect),
        work_life = outlier.na(work_life, max = Inf)
    )

    X <- as.matrix(X[features])

    y <- predict(simplified.xg.model, newdata = X, ntreelimit = simplified.xg.model$best_ntreelimit)
    y
}

score_v2 <- cash.score.v2(cash.all.sample)
cash.all.sample$score_v2 <- score_v2
