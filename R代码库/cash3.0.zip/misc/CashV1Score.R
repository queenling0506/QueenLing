library(RODBC)
library(magrittr)
library(dplyr)

conn <- odbcConnect('impalaodbc', uid = 'siyuan.yao', pwd = '1d63b837fce3e3984a7c52a97292a830')
cash.sample <- sqlQuery(conn, 'SELECT * FROM risk_analysis.cash_loan_model_variables_ling_0905 A
                        WHERE appl_tm >= \'2016-01-01\'',
                        as.is = TRUE,
                        na.strings = c('NULL', '', '--'))
close(conn)
remove(conn)

# variable transformation
# Note: Special processing for 99999999999 values
cash.sample <- cash.sample %>% mutate(
    v_gender_cd_woe = ifelse(gender_cd == '0', -48.4, 9.1),
    v_diploma_woe = ifelse(is.na(diploma), 11.0, ifelse(diploma == '文盲或半文盲' | diploma == '小学' | diploma == '技术学校' | diploma == '初中', 50.9, ifelse(diploma == '高中' | diploma == '中等专业学校或中等技术学校', 12.5, ifelse(diploma == '大学专科和专科学校（简称"大专"）', -24.3, -42.9)))),
    v_add_corltt_woe = ifelse(is.na(add_corltt), 9.7, ifelse(add_corltt <= 34, -17.3, ifelse(add_corltt<= 42, 19.9, 60.4))),

    numc_acct = numc_acct %>% ifelse(is.na(.), 0, .),
    v_numc_acct_woe = ifelse(numc_acct <= 0, 48.0, ifelse(numc_acct <= 1, 35.0, ifelse(numc_acct <= 3, 6.7, ifelse(numc_acct <= 5, -22.3, -59.2)))),

    nums_acct = nums_acct %>% ifelse(is.na(.), 0, .),
    v_nums_acct_woe = ifelse(nums_acct <= 0, 5.1, -41.7),
    v_numl_lpdm_woe = ifelse(is.na(numl_lpdm), 3.5, ifelse(numl_lpdm <= 0, -22.3, ifelse(numl_lpdm <= 2, 29.7, 86.9))),
    v_numc_acctpd_woe = ifelse(is.na(numc_acctpd), 3.5, ifelse(numc_acctpd <= 0, 66.4, ifelse(numc_acctpd <= 1, -7.9, ifelse(numc_acctpd <= 2, -15.6, ifelse(numc_acctpd <= 3, -52.6, -67.2))))),
    v_amtc_htpdever_woe = ifelse(is.na(amtc_htpdever), 3.5, ifelse(amtc_htpdever <= 0, 11, -20.3)),
    v_numc_lpdm_woe = ifelse(is.na(numc_lpdm), 3.5, ifelse(numc_lpdm <= 0, 66.4, -20.4)),
    v_numl_insos_woe = ifelse(is.na(numl_insos), 16.1, ifelse(numl_insos <= 1, 10.1, ifelse(numl_insos <= 2, -20.6, -66.6))),
    v_numl_os_woe = ifelse(is.na(numl_os), 16.1, ifelse(numl_os <= 1, 13.6, ifelse(numl_os <= 2, -12.4, -54.4))),
    v_amtl_apos6m_woe = ifelse(is.na(amtl_apos6m), 16.1, ifelse(amtl_apos6m <= 1000, 6.4, ifelse(amtl_apos6m <= 3000, -42.2, -79.2))),
    v_amtc_utlcop_woe = ifelse(is.na(amtc_utlcop), 49.1, ifelse(amtc_utlcop <= 0, 32.2, ifelse(amtc_utlcop <= 7000, -4, ifelse(amtc_utlcop <= 28000, -17.8, ifelse(amtc_utlcop <= 67000, -46.2, -85.3))))),
    v_no_mob_woe = ifelse(no_mob <= 0, 55, -6.1),
    v_no_telwk_woe = ifelse(no_telwk <= 0, 39.7, -9.3),
    v_num_emp2y_woe = ifelse(is.na(num_emp2y) | num_emp2y <= 1, 19.3, ifelse(num_emp2y <= 2, -3, ifelse(num_emp2y <= 3, -37.9, -9.6))),

    # Exception
    varsmaxcdiffreptmandisstmineffect = varsmaxcdiffreptmandisstmineffect %>% ifelse(. > 999999900, NA, .),
    v_varsmaxcdiffreptmandisstmineffect_woe = ifelse(varsmaxcdiffreptmandisstmineffect %>% is.na, 48.5, ifelse(varsmaxcdiffreptmandisstmineffect <= 127, 46.1, ifelse(varsmaxcdiffreptmandisstmineffect <= 220, 14.9, ifelse(varsmaxcdiffreptmandisstmineffect <= 816, -9.9, -57.3)))),

    varsmaxcdiffreptmandisstmnotactivated = varsmaxcdiffreptmandisstmnotactivated %>% ifelse(. > 999999900, NA, .),
    v_varsmaxcdiffreptmandisstmnotactivated_woe = ifelse(varsmaxcdiffreptmandisstmnotactivated %>% is.na, 9.5, ifelse(varsmaxcdiffreptmandisstmnotactivated <= 400, -35.3, -66.7)),

    rtnumcacctnormaltonumc = rtnumcacctnormaltonumc %>% ifelse(. > 999999900, NA, .),
    v_rtnumcacctnormaltonumc_woe = ifelse(is.na(rtnumcacctnormaltonumc), 48.5, ifelse(rtnumcacctnormaltonumc <= 0.17, 39.8, ifelse(rtnumcacctnormaltonumc <= 0.96, -44.9, -4.1))),

    amtc_1srpa120 = amtc_1srpa120 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1srpa120_woe = ifelse(is.na(amtc_1srpa120), 48.6, ifelse(amtc_1srpa120 <= 0, 15.5, ifelse(amtc_1srpa120 <= 1000, -5.4, ifelse(amtc_1srpa120 <= 2000, -29, -60.4)))),

    amtc_1smua120 = amtc_1smua120 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1smua120_woe = ifelse(is.na(amtc_1smua120), 48.6, ifelse(amtc_1smua120 <= 2000, 15.4, ifelse(amtc_1smua120 <= 15000, -13.4, ifelse(amtc_1smua120 <= 35000, -25.1, -55.7)))),

    amtc_1m6la120 = amtc_1m6la120 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1m6la120_woe = ifelse(is.na(amtc_1m6la120), 48.6, ifelse(amtc_1m6la120 <= 15000, -15.2, ifelse(amtc_1m6la120 <= 26000, -51.7, -67.7))),

    amtc_1ssla120 = amtc_1ssla120 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1ssla120_woe = ifelse(is.na(amtc_1ssla120), 48.6, ifelse(amtc_1ssla120 <= 20000, -4.1, ifelse(amtc_1ssla120 <= 59000, -41.7, -91.2))),

    amtc_1lsla120 = amtc_1lsla120 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1lsla120_woe = ifelse(is.na(amtc_1lsla120), 48.6, ifelse(amtc_1lsla120 <= 0, -36.6, 8)),

    amtc_1lula120 = amtc_1lula120 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1lula120_woe = ifelse(is.na(amtc_1lula120), 48.6, ifelse(amtc_1lula120 <= 600, -35.8, ifelse(amtc_1lula120 <= 4800, 0, 29.5))),

    amtc_1lcla120 = amtc_1lcla120 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1lcla120_woe = ifelse(is.na(amtc_1lcla120), 48.6, ifelse(amtc_1lcla120 <= 2000, -22.6, ifelse(amtc_1lcla120 <= 3000, -49.3, ifelse(amtc_1lcla120 <= 8000, -24, -2.6)))),

    amtc_1srpa030 = amtc_1srpa030 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1srpa030_woe = ifelse(is.na(amtc_1srpa030), 50.1, ifelse(amtc_1srpa030 <= 0, 32.9, ifelse(amtc_1srpa030 <= 1000, -2.2, ifelse(amtc_1srpa030 <= 2000, -22.5, ifelse(amtc_1srpa030 <= 6000, -45.3, -108.8))))),

    amtc_1srpa000 = amtc_1srpa000 %>% ifelse(. > 999999900, NA, .),
    v_amtc_1srpa000_woe = ifelse(is.na(amtc_1srpa000), 49.3, ifelse(amtc_1srpa000 <= 0, 30, ifelse(amtc_1srpa000 <= 1000, 0.9, ifelse(amtc_1srpa000 <= 2000, -15.9, -57.8)))),

    amtc_trp = amtc_trp %>% ifelse(. > 999999900, NA, .),
    v_amtc_trp_woe = ifelse(is.na(amtc_trp), 48.2, ifelse(amtc_trp <= 0, 26.2, ifelse(amtc_trp <= 1000, 2.1, ifelse(amtc_trp <= 2000, -16.6, -54.9)))),

    jion_life_insure = ifelse(is.na(jion_life_insure), 0, jion_life_insure),
    v_jion_life_insure_woe = ifelse(jion_life_insure == '0', -52.2, 20.1)
)

## calculation for response variable
predictors <- colnames(cash.sample)[grepl('^v_.*_woe$', colnames(cash.sample))]

coeffi <- c(
                         v_gender_cd_woe = -0.010928479,
 v_varsmaxcdiffreptmandisstmineffect_woe = -0.006327375,
                        v_add_corltt_woe = -0.011462556,
                         v_numc_acct_woe = -0.001688082,
                       v_amtl_apos6m_woe = -0.004985679,
                           v_diploma_woe = -0.005127663,
                     v_amtc_1srpa030_woe = -0.007293032,
                       v_amtc_utlcop_woe =  0.005458718,
                          v_amtc_trp_woe =  0.025262522,
                         v_numl_lpdm_woe = -0.005139233,
                     v_amtc_htpdever_woe =  0.009328816,
                     v_amtc_1lula120_woe = -0.006038963,
                           v_numl_os_woe = -0.006562935,
                     v_amtc_1srpa000_woe = -0.019637152,
v_varsmaxcdiffreptmandisstmnotactivated_woe = -0.004899577,
                       v_numc_acctpd_woe = -0.005861348,
                        v_numl_insos_woe =  0.002321772,
                     v_amtc_1lsla120_woe =  0.003714405,
                         v_numc_lpdm_woe =  0.001814589,
                            v_no_mob_woe = -0.004317787,
                          v_no_telwk_woe =  0.005355742,
                     v_amtc_1lcla120_woe = -0.002273283,
                     v_amtc_1m6la120_woe =  0.002374911,
                     v_amtc_1ssla120_woe = -0.001840629,
                     v_amtc_1smua120_woe =  0.004334201,
                     v_amtc_1srpa120_woe = -0.006266660,
                         v_nums_acct_woe = -0.004548663,
                         v_num_emp2y_woe =  0.001126366,
            v_rtnumcacctnormaltonumc_woe =  0.003391351,
                  v_jion_life_insure_woe = -0.009286688
)
coeffi <- coeffi[predictors]

### Matrix multiplication: y = a[1]*x[1] + ... + a[n]*x[n]
y <- as.matrix(cash.sample[, predictors]) %*% cbind(coeffi)

## calculate the score
score <- exp(y[, 1]) / (1 + exp(y[, 1]))

cash.all.sample <- cbind(cash.sample, score_v1 = score)

rm(coeffi)
rm(predictors)
rm(score)
rm(cash.sample)
rm(y)
