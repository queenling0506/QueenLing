#' RiskCLFradApi
#'
#' @param PARAM a list of parameters
#'
#' @details
#'   ID_UNQF    ID of PBOC report
#'   gender_cd  gender, M/F
#' @examples
#' RiskCLFradApi(list(IDUNQF = '4852d8a9b7cf4f92ba260949adcfb2d8'))
#' @export

RiskCLFradApi = function(PARAM) {
    ## Start timestamp
    start.ts = as.numeric(proc.time()[3])
    ## DEGUG Flag
    .ver = unname(getNamespaceVersion('RiskCLFradProject'))
    debug.flag = as.numeric(strsplit(.ver, '\\.')[[1]][2]) %% 2 == 1
    # debug.flag = TRUE
    ## Request UUID
    app.uuid = uuid::UUIDgenerate(TRUE)
    ## logger setting
    CLLOG = "RiskCLFradApi"
    CLLOG_ERR = "RiskCLFradApi.err"
    logger.layout = futile.logger::layout.format('~t ~l  ~n:~f  ~m')
    futile.logger::flog.layout(logger.layout, name = CLLOG)
    futile.logger::flog.layout(logger.layout, name = CLLOG_ERR)
    futile.logger::flog.threshold(futile.logger::INFO, name = CLLOG)
    futile.logger::flog.threshold(futile.logger::ERROR, name = CLLOG_ERR)
    ## logging file
    logged.info = list(UUID = app.uuid, Input = PARAM)
    log.path = ifelse(debug.flag,
                      ifelse(file.exists('/home/finance/Logs/riskbrain.msxf.lo/'),
                             '/home/finance/Logs/riskbrain.msxf.lo/', '~/'),
                      '/home/finance/Logs/riskbrain.msxf.lo/')
    # log.path = '/home/finance/Logs/datarocket.msxf.lo/'
    infofile = 'RiskCLFradApi-info.log.'
    errofile = 'RiskCLFradApi-err.log.'
    date = strftime(Sys.time(), '%Y%m%d')
    info.appender = futile.logger::appender.file(paste0(log.path, infofile, date))
    err.appender = futile.logger::appender.file(paste0(log.path, errofile, date))
    futile.logger::flog.appender(info.appender, name = CLLOG)
    futile.logger::flog.appender(err.appender, name = CLLOG_ERR)

    ## Check PARAM content
    id_unqf = ifelse(exists('IDUNQF', PARAM), PARAM$IDUNQF, NA)
    # The following infomation are not desired to use by the business line
    gender_cd = ifelse(exists('genderCd', PARAM), PARAM$genderCd, 'M')
    jion_life_insure = ifelse(exists('jionLifeInsure', PARAM),
                              PARAM$jionLifeInsure, 'Y')
    mo_earn = ifelse(exists('moEarn', PARAM), PARAM$moEarn, 0)
    oth_earn = ifelse(exists('othEarn', PARAM), PARAM$othEarn, 0)
    oth_loan = ifelse(exists('othLoan', PARAM), PARAM$othLoan, 0)
    work_life = ifelse(exists('workLife', PARAM), PARAM$workLife, 0)

    # No id_unqf is found
    if (is.na(id_unqf)) {
        # end timestamp
        end.ts = as.numeric(proc.time()[3])
        logged.info$Msg = "No ID_UNQF is found"
        logged.info$Output = list(cash_score_v2 = -1)
        logged.info$TimeElapse = round(end.ts - start.ts, 4)
        futile.logger::flog.error(rjson::toJSON(logged.info), name = CLLOG_ERR)
        return(logged.info$Output)
    }

    PARAM$gender_cd = gender_cd
    PARAM$jion_life_insure = jion_life_insure
    PARAM$mo_earn = as.numeric(mo_earn)
    PARAM$oth_earn = as.numeric(oth_earn)
    PARAM$oth_loan = as.numeric(oth_loan)
    PARAM$work_life = as.numeric(work_life)

    # Obtain data from DP's interface
    ## Some utility function
    error.handling = function(err) {
        end.ts = as.numeric(proc.time()[3])
        logged.info$Msg <<- paste0(conditionMessage(err), " from ", interface,
                                   collapse = "")
        logged.info$Output <<- list(cash_score_v2 = -1)
        logged.info$TimeElapse <<- round(end.ts - start.ts, 4)
        futile.logger::flog.error(rjson::toJSON(logged.info), name = CLLOG_ERR)
        NULL
    }

    null2na = function(x, num = TRUE) {
        x = ifelse(is.null(x), NA, x)
        if (num) return(as.numeric(x)) else x
    }

    ## Basic info
    interface = 'pboc_credit_data'
    pboc.basinfo = tryCatch(EDS.Call(app.uuid, id_unqf,
        service.code = interface, product.code = '1101',
        .debug = debug.flag), error = error.handling)
    if (is.null(pboc.basinfo)) return(logged.info$Output)
    # Get the content of basic info
    pboc.basinfo = pboc.basinfo$data$content$personBasicinf
    # Insert data into PARAM
    PARAM$add_corlng = null2na(pboc.basinfo$addCorlng)
    PARAM$add_corltt = null2na(pboc.basinfo$addCorltt)
    PARAM$add_hjlng = null2na(pboc.basinfo$addHjlng)
    PARAM$add_hjltt = null2na(pboc.basinfo$addHjltt)
    PARAM$amtc_htpdever = null2na(pboc.basinfo$amtcHtpdever)
    PARAM$amtc_utlcop = null2na(pboc.basinfo$amtcUtlcop)
    PARAM$amtl_apos6m = null2na(pboc.basinfo$amtlApos6m)
    PARAM$amtl_os = null2na(pboc.basinfo$amtlOs)
    PARAM$diploma = null2na(pboc.basinfo$diploma, num = FALSE)
    PARAM$numc_lpop = null2na(pboc.basinfo$numcLpop)
    PARAM$numc_pdm = null2na(pboc.basinfo$numcPdm)
    PARAM$numi_acctm2y = null2na(pboc.basinfo$numiAcctm2y)
    PARAM$numi_self1m = null2na(pboc.basinfo$numiSelf1m)
    PARAM$numi_wq2y = null2na(pboc.basinfo$numiWq2y)
    PARAM$numl_os = null2na(pboc.basinfo$numlOs)
    PARAM$numl_others = null2na(pboc.basinfo$numlOthers)
    PARAM$numl_pd = null2na(pboc.basinfo$numlPd)
    PARAM$nums_acctpd3p = null2na(pboc.basinfo$numsAcctpd3p)
    PARAM$timel_fsti = as.Date(paste0(null2na(pboc.basinfo$timelFsti, num = FALSE),
                                      '.01'), '%Y.%m.%d')
    PARAM$timec_fsti = as.Date(paste0(null2na(pboc.basinfo$timecFsti, num = FALSE),
                                      '.01'), '%Y.%m.%d')
    PARAM$times_fsti = as.Date(paste0(null2na(pboc.basinfo$timesFsti, num = FALSE),
                                      '.01'), '%Y.%m.%d')

    month.interval = function(x, now = Sys.time()) {
        now = as.Date(now)
        x = as.Date(x)
        round(as.numeric(now - x) / 30.42, 1)
    }

    PARAM$diploma = ifelse(is.na(PARAM$diploma), 'others',
        ifelse(PARAM$diploma == "\u5927\u5b66\u672c\u79d1\uff08\u7b80\u79f0\u22\u5927\u5b66\u22\uff09", 'university',
        ifelse(PARAM$diploma == "\u7814\u7a76\u751f", 'postgraduate', 'others')))
    PARAM$timel_fsti = month.interval(PARAM$timel_fsti)
    PARAM$timec_fsti = month.interval(PARAM$timec_fsti)
    PARAM$times_fsti = month.interval(PARAM$times_fsti)
    # End of Basic Info

    # PBOC1
    interface = 'pboc_credit_variable'
    pboc1 = tryCatch(EDS.Call(app.uuid, id_unqf,
        service.code = interface, product.code = '1101',
        .debug = debug.flag), error = error.handling)
    if (is.null(pboc1)) return(logged.info$Output)
    # Get the content of PBOC1
    pboc1 = pboc1$data$content
    PARAM$amtc_acttpd = null2na(pboc1$amtcActtpd)
    PARAM$amtl_inactlpd = null2na(pboc1$amtlInactlpd)
    PARAM$num_empc2y = null2na(pboc1$numEmpc2y)
    PARAM$numi_3m = null2na(pboc1$numi3m)
    PARAM$numi_rh3m = null2na(pboc1$numiRh3m)
    PARAM$numl_emtglrrp = null2na(pboc1$numlEmtglrrp)
    PARAM$numl_inactemtglpdm = null2na(pboc1$numlInactemtglpdm)
    PARAM$numl_lrrp = null2na(pboc1$numlLrrp)
    PARAM$ratc_actrp = null2na(pboc1$ratcActrp)
    # End of PBOC1

    # PBOC2
    interface = 'pboc_credit_blaze_variable'
    pboc2 = tryCatch(EDS.Call(app.uuid, id_unqf,
        service.code = interface, product.code = '1101',
        .debug = debug.flag), error = error.handling)
    if (is.null(pboc2)) return(logged.info$Output)
    # Get the content of PBOC1
    pboc2 = pboc2$data$content
    PARAM$amtc_1lula120 = null2na(pboc2$amtc1lula120)
    PARAM$amtc_1m6la030 = null2na(pboc2$amtc1m6la030)
    PARAM$amtc_1mapa060 = null2na(pboc2$amtc1mapa060)
    PARAM$amtc_1sapa060 = null2na(pboc2$amtc1sapa060)
    PARAM$amtc_1scla120 = null2na(pboc2$amtc1scla120)
    PARAM$amtc_1srpa060 = null2na(pboc2$amtc1srpa060)
    PARAM$amtc_1ssla060 = null2na(pboc2$amtc1ssla060)
    PARAM$amtl_1mprw03woww = null2na(pboc2$amtl1mprw03woww)
    PARAM$numc_1mr6awww = null2na(pboc2$numc1mr6awww)
    PARAM$numc_1scca031 = null2na(pboc2$numc1scca031)
    PARAM$numc_1scca240 = null2na(pboc2$numc1scca240)
    PARAM$numc_1sccw030 = null2na(pboc2$numc1sccw030)
    PARAM$numc_1sccw120 = null2na(pboc2$numc1sccw120)
    PARAM$numl_1caca030www = null2na(pboc2$numl1caca030www)
    PARAM$numl_1caca031www = null2na(pboc2$numl1caca031www)
    PARAM$numl_1cacw06woww = null2na(pboc2$numl1cacw06woww)
    PARAM$numl_1mpla03wwww = null2na(pboc2$numl1mpla03wwww)
    PARAM$numl_1mplw03wwww = null2na(pboc2$numl1mplw03wwww)
    PARAM$numl_1mplw06wwww = null2na(pboc2$numl1mplw06wwww)
    PARAM$numl_1mplw12wwww = null2na(pboc2$numl1mplw12wwww)
    PARAM$numl_1spdw06wwww = null2na(pboc2$numl1spdw06wwww)
    PARAM$numl_1spdw12wwww = null2na(pboc2$numl1spdw12wwww)
    PARAM$numl_3ltmtiw = null2na(pboc2$numl3ltmtiw)
    PARAM$numl_3mtmtiw = null2na(pboc2$numl3mtmtiw)
    PARAM$pbc1_peinum_emp2y = null2na(pboc2$pbc1PeinumEmp2y)
    PARAM$pbc1_pidnum_lcs6m = null2na(pboc2$pbc1PidnumLcs6m)
    PARAM$pbc1_plitimes_2y = null2na(pboc2$pbc1Plitimes2y)
    PARAM$rtoc_1m6ca030 = null2na(pboc2$rtoc1m6ca030)
    PARAM$rtoc_1mmca000 = null2na(pboc2$rtoc1mmca000)
    PARAM$rtoc_1muca000 = null2na(pboc2$rtoc1muca000)
    PARAM$varsmaxcdiffreptmandisstmineffect =
        null2na(pboc2$varsmaxcdiffreptmandisstmineffect)
    # End of PBOC2

    PARAM = as.data.frame(PARAM, stringsAsFactors = FALSE)
    score = tryCatch(cash.score.v2(PARAM), error = function(err) {
        logged.info$PARAM <<- PARAM
        end.ts = as.numeric(proc.time()[3])
        logged.info$Msg <<- conditionMessage(err)
        logged.info$Output <<- list(cash_score_v2 = -1)
        logged.info$TimeElapse <<- round(end.ts - start.ts, 4)
        futile.logger::flog.error(rjson::toJSON(logged.info), name = CLLOG_ERR)
        NULL
    })
    if (is.null(score)) return(logged.info$Output)

    output = list(cash_score_v2 = score)
    end.ts = as.numeric(proc.time()[3])
    logged.info$Msg = 'Success'
    logged.info$Output = output
    logged.info$TimeElapse = round(end.ts - start.ts, 4)
    logged.info$Input = PARAM
    futile.logger::flog.info(rjson::toJSON(logged.info), name = CLLOG)

    output
}