#' @import xgboost
cash.score.v2 <- function(X) {
    # some data cleansing work
    outlier.na <- function(x, min = 0, max = 999999900) {
        x <- as.numeric(x)
        ifelse(!is.na(x) & x >= min & x < max, x, NA)
    }

    X <- dplyr::mutate(X,
        'add_corlng' = outlier.na(X$add_corlng, 73, 136),
        'add_corltt' = outlier.na(X$add_corltt, 3, 54),
        'add_hjlng' = outlier.na(X$add_hjlng, 73, 136),
        'add_hjltt' = outlier.na(X$add_hjltt, 3, 54),
        'amtc_1lula120' = outlier.na(X$amtc_1lula120),
        'amtc_1m6la030' = outlier.na(X$amtc_1m6la030),
        'amtc_1mapa060' = outlier.na(X$amtc_1mapa060),
        'amtc_1sapa060' = outlier.na(X$amtc_1sapa060),
        'amtc_1scla120' = outlier.na(X$amtc_1scla120),
        'amtc_1srpa060' = outlier.na(X$amtc_1srpa060),
        'amtc_1ssla060' = outlier.na(X$amtc_1ssla060),
        'amtc_acttpd' = outlier.na(X$amtc_acttpd),
        'amtc_htpdever' = outlier.na(X$amtc_htpdever, max = Inf),
        'amtc_utlcop' = outlier.na(X$amtc_utlcop),
        'amtl_1mprw03woww' = outlier.na(X$amtl_1mprw03woww),
        'amtl_apos6m' = outlier.na(X$amtl_apos6m, max = Inf),
        'amtl_inactlpd' = outlier.na(X$amtl_inactlpd),
        'amtl_os' = outlier.na(X$amtl_os, max = Inf),
        'v_diploma_D' = ifelse(is.na(X$diploma), 0,
            ifelse(X$diploma == 'university' | X$diploma == 'postgraduate',
                1, 0)),
        'gender_cd_1' = ifelse(is.na(X$gender_cd) | X$gender_cd == 'M', 1, 0),
        'jion_life_insure_1' = ifelse(is.na(X$jion_life_insure) | X$jion_life_insure == 'Y', 1, 0),
        'mo_earn' = outlier.na(X$mo_earn, max = Inf),
        'num_empc2y' = outlier.na(X$num_empc2y, max = 5),
        'numc_1mr6awww' = outlier.na(X$numc_1mr6awww),
        'numc_1scca031' = outlier.na(X$numc_1scca031),
        'numc_1scca240' = outlier.na(X$numc_1scca240),
        'numc_1sccw030' = outlier.na(X$numc_1sccw030),
        'numc_1sccw120' = outlier.na(X$numc_1sccw120),
        'numc_lpop' = outlier.na(X$numc_lpop, max = 50),
        'numc_pdm' = outlier.na(X$numc_pdm, max = Inf),
        'numi_3m' = outlier.na(X$numi_3m, max = Inf),
        'numi_acctm2y' = outlier.na(X$numi_acctm2y, max = Inf),
        'numi_rh3m' = outlier.na(X$numi_rh3m, max = Inf),
        'numi_self1m' = outlier.na(X$numi_self1m, max = Inf),
        'numi_wq2y' = outlier.na(X$numi_wq2y, max = Inf),
        'numl_1caca030www' = outlier.na(X$numl_1caca030www),
        'numl_1caca031www' = outlier.na(X$numl_1caca031www),
        'numl_1cacw06woww' = outlier.na(X$numl_1cacw06woww),
        'numl_1mpla03wwww' = outlier.na(X$numl_1mpla03wwww),
        'numl_1mplw03wwww' = outlier.na(X$numl_1mplw03wwww),
        'numl_1mplw06wwww' = outlier.na(X$numl_1mplw06wwww),
        'numl_1mplw12wwww' = outlier.na(X$numl_1mplw12wwww),
        'numl_1spdw06wwww' = outlier.na(X$numl_1spdw06wwww),
        'numl_1spdw12wwww' = outlier.na(X$numl_1spdw12wwww),
        'numl_3ltmtiw' = outlier.na(X$numl_3ltmtiw),
        'numl_3mtmtiw' = outlier.na(X$numl_3mtmtiw),
        'numl_emtglrrp' = outlier.na(X$numl_emtglrrp, max = 9000),
        'numl_inactemtglpdm' = outlier.na(X$numl_inactemtglpdm, max = 9000),
        'numl_lrrp' = outlier.na(X$numl_lrrp, max = 9000),
        'numl_os' = outlier.na(X$numl_os, max = Inf),
        'numl_others' = outlier.na(X$numl_others, max = Inf),
        'numl_pd' = outlier.na(X$numl_pd, max = Inf),
        'nums_acctpd3p' = outlier.na(X$nums_acctpd3p, max = Inf),
        'oth_earn' = outlier.na(X$oth_earn, max = Inf),
        'oth_loan' = outlier.na(X$oth_loan, max = Inf),
        'pbc1_peinum_emp2y' = outlier.na(X$pbc1_peinum_emp2y),
        'pbc1_pidnum_lcs6m' = outlier.na(X$pbc1_pidnum_lcs6m),
        'pbc1_plitimes_2y' = outlier.na(X$pbc1_plitimes_2y),
        'ratc_actrp' = outlier.na(X$ratc_actrp),
        'rtoc_1m6ca030' = outlier.na(X$rtoc_1m6ca030),
        'rtoc_1mmca000' = outlier.na(X$rtoc_1mmca000),
        'rtoc_1muca000' = outlier.na(X$rtoc_1muca000),
        'timel_fsti' = outlier.na(X$timel_fsti, max = Inf),
        'timec_fsti' = outlier.na(X$timec_fsti, max = Inf),
        'times_fsti' = outlier.na(X$times_fsti, max = Inf),
        'time_credit' = pmax(X$timel_fsti,
            X$timec_fsti, X$times_fsti, na.rm = TRUE),
        'varsmaxcdiffreptmandisstmineffect' =
            outlier.na(X$varsmaxcdiffreptmandisstmineffect),
        'work_life' = outlier.na(X$work_life, max = Inf)
    )

    X <- as.matrix(X[features])
    X[is.nan(X)] <- NA

    y <- predict(simplified.xg.model,
        newdata = X, ntreelimit = simplified.xg.model$best_ntreelimit,
        missing = c(NA, NaN))
    y
}