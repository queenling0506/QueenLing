library(xgboost)
library(data.table)

# With resampling
train <- readRDS('data/train.rds')
set.seed(2017)
n_train_good <- sum(train$target == 'Good')
n_train_bad  <- sum(train$target == 'Bad')
train <- rbind(
    train[target == 'Good'][sample(n_train_good, n_train_bad)],
    train[target == 'Bad']
)
invisible(train[, id_unqf := NULL])
invisible(train[, target := ifelse(target == 'Bad', 1, 0)])
for (col in colnames(train)[-1]) {
    code <- sprintf("invisible(train[, %s := ifelse(%s >= 999999000, NA, %s)])",
                    col, col, col)
    eval(parse(text = code))
}
train_dm <- xgb.DMatrix(as.matrix(train[, -1]), label = train$target)

test1 <- readRDS('data/test1.rds')
invisible(test1[, id_unqf := NULL])
invisible(test1[, target := ifelse(target == 'Bad', 1, 0)])
for (col in colnames(test1)[-1]) {
    code <- sprintf("invisible(test1[, %s := ifelse(%s >= 999999000, NA, %s)])",
                    col, col, col)
    eval(parse(text = code))
}
test1_dm <- xgb.DMatrix(as.matrix(test1[, -1]), label = test1$target)


set.seed(2017)

## 1. tuning depth

depth_perf <- NULL

for (depth in 1:6) {
    tmp_model <- xgb.train(
        params = list(
            nthread = 64,
            objective = 'binary:logistic',
            eta = 0.5,
            subsample = 0.1,
            max_depth = depth,
            eval_metric = 'auc'
        ),
        data = train_dm,
        watchlist = list(
            train = train_dm,
            test1 = test1_dm
        ),
        nrounds = 1000,
        print_every_n = 10,
        early_stopping_rounds = 100,
        seed = 1024,
        verbose = 1
    )

    max_auc = max(tmp_model$evaluation_log$test_auc_mean)

    depth_perf <- rbind(depth_perf, data.table(
        depth = depth,
        auc = max_auc
    ))
}

best_depth <- depth_perf[auc == max(auc), depth]


## 2. tuning alpha and lambda
set.seed(2017)
reg_perf <- NULL

for (alpha in c(0, 2^(-2:3))) {
    for (lambda in c(0, 2^(-2:3))) {
        tmp_model <- xgb.train(
            params = list(
                nthread = 64,
                objective = 'binary:logistic',
                eta = 0.1,
                subsample = 0.5,
                max_depth = best_depth,
                alpha = alpha,
                lambda = lambda,
                eval_metric = 'auc'
            ),
            data = train_dm,
            watchlist = list(
                train = train_dm,
                test1 = test1_dm
            ),
            nrounds = 1000,
            print_every_n = 10,
            early_stopping_rounds = 100,
            seed = 1024,
            verbose = 1
        )
    }

    max_auc = max(tmp_model$evaluation_log$test_auc_mean)
    reg_perf <- rbind(reg_perf, data.table(
        alpha = alpha,
        lambda = lambda,
        auc = max_auc
    ))
}

best_reg <- as.list(reg_perf[auc == max(auc), .(alpha, lambda)])

## 3. tuning gamma
set.seed(2017)
gamma_perf <- NULL

for (gamma in c(0, 2^(-2:3))) {
    tmp_model <- xgb.train(
        params = list(
            nthread = 64,
            objective = 'binary:logistic',
            eta = 0.1,
            subsample = 0.5,
            max_depth = depth,
            alpha = best_reg$alpha,
            lambda = best_reg$lambda,
            gamma = gamma,
            eval_metric = 'auc'
        ),
        data = train_dm,
        watchlist = list(
            train = train_dm,
            test1 = test1_dm
        ),
        nrounds = 1000,
        print_every_n = 10,
        early_stopping_rounds = 100,
        seed = 1024,
        verbose = 1
    )

    max_auc = max(tmp_model$evaluation_log$test_auc_mean)

    gamma_perf <- rbind(gamma_perf, data.table(
        gamma = gamma,
        auc = max_auc
    ))
}

best_gamma <- gamma_perf[auc == max(auc), gamma]

cat(sprintf("Best parameters:\n\tmax_depth\t:\t%s\n\talpha\t:\t%s\n\tlambda\t:\t%s\n\tgamma\t:\t%s\n",
            best_depth, best_reg$alpha, best_reg$lambda, best_gamma))


set.seed(2017)
xg.model <- xgb.cv(
    params = list(
        nthread = 64,
        objective = 'binary:logistic',
        eta = 0.1,
        subsample = 0.5,
        max_depth = 4,
        alpha = 8,
        lambda = 8,
        gamma = 8,
        eval_metric = 'auc'
    ),
    data = train_dm,
    # watchlist = list(
    #     train = train_dm,
    #     test1 = test1_dm
    # ),
    nrounds = 1000,
    print_every_n = 10,
    early_stopping_rounds = 100,
    seed = 1024,
    verbose = 1,
    nfold = 2,
    stratified = TRUE,
    showsd = TRUE,
    metrics = 'auc'
)

pboc_generic_xg_nrsmp <- xg.model

save(pboc_generic_xg_nrsmp,
     file = 'pboc_generic_xg_nrsmp.rda',
     compress = TRUE,
     compression_level = 9)
