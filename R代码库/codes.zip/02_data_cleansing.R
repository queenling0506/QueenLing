library(data.table)
library(magrittr)
load("all_data.rda")

# remove duplicated clients
dup_id <- unique(master_table$id_unqp[duplicated(master_table$id_unqp)])
no_dup_id <- master_table$id_unqp[!master_table$id_unqp %in% dup_id]
master_table <- master_table[id_unqp %in% no_dup_id]

# remove duplicated report id
no_dup_id <- compiler::cmpfun(function(dt) {
    dup_id <- dt$id_unqf[duplicated(dt$id_unqf)]
    dt[!id_unqf %in% dup_id]
})

lcd <- no_dup_id(lcd)
lld <- no_dup_id(lld)
pbi <- no_dup_id(pbi)
lsd <- no_dup_id(lsd)
int <- no_dup_id(int)

final_id <- master_table$id_unqf %>%
    intersect(lcd$id_unqf) %>%
    intersect(lld$id_unqf) %>%
    intersect(pbi$id_unqf) %>%
    intersect(lsd$id_unqf) %>%
    intersect(int$id_unqf)

master_table <- master_table[id_unqf %in% final_id]
lcd <- lcd[id_unqf %in% final_id]
lld <- lld[id_unqf %in% final_id]
pbi <- pbi[id_unqf %in% final_id]
lsd <- lsd[id_unqf %in% final_id]
int <- int[id_unqf %in% final_id]

# data cleansing
lcd[, `:=`(id_unqp = NULL,
           flag_valid = NULL,
           flag_c = NULL,
           dt = NULL,
           time_inst = NULL,
           time_rep = NULL,
           time_upd = NULL)]
lld[, `:=`(id_unqp = NULL,
           flag_valid = NULL,
           flag_l = NULL,
           dt = NULL,
           time_inst = NULL,
           time_rep = NULL,
           time_upd = NULL)]
lsd[, `:=`(id_unqp = NULL,
           flag_valid = NULL,
           flag_s = NULL,
           dt = NULL,
           time_inst = NULL,
           time_rep = NULL,
           time_upd = NULL)]
pbi[, `:=`(id_unqp = NULL,
           flag_valid = NULL,
           dt = NULL,
           flag_repstts = NULL,
           time_inst = NULL,
           time_rep = NULL,
           time_upd = NULL)]
int[, `:=`(id_unqp = NULL,
           flag_valid = NULL,
           dt = NULL,
           flag_lcs = NULL,
           time_inst = NULL,
           time_rep = NULL,
           time_upd = NULL)]

invisible(lld[, `:=`(
    ratl_3mprrtw = as.numeric(ratl_3mprrtw),
    ratl_3ltmrtw = as.numeric(ratl_3ltmrtw),
    ratl_1wrtwwwwwww = as.numeric(ratl_1wrtwwwwwww),
    ratl_1wrtwwwwwws = as.numeric(ratl_1wrtwwwwwws),
    ratl_1wrtwwwwwwm = as.numeric(ratl_1wrtwwwwwwm),
    ratl_1wrtwwwwwwc = as.numeric(ratl_1wrtwwwwwwc),
    ratl_1wrtwwwwwwb = as.numeric(ratl_1wrtwwwwwwb),
    ratl_1wrtwwwwwwa = as.numeric(ratl_1wrtwwwwwwa),
    ratl_3mtmrtw = as.numeric(ratl_3mtmrtw),
    ratl_1wrtwwwwwgw = as.numeric(ratl_1wrtwwwwwgw),
    ratl_1wrtwwwwwgc = as.numeric(ratl_1wrtwwwwwgc),
    ratl_1wrtwwwwwgb = as.numeric(ratl_1wrtwwwwwgb)
)])

invisible(lcd[, `:=`(
    ratc_1lwrhwww = as.numeric(ratc_1lwrhwww),
    ratc_1mwrawww = as.numeric(ratc_1mwrawww),
    ratc_1mwrhwww = as.numeric(ratc_1mwrhwww),
    ratc_1lwrwwww = as.numeric(ratc_1lwrwwww),
    ratc_1mwrwwww = as.numeric(ratc_1mwrwwww),
    ratc_1lwrawww = as.numeric(ratc_1lwrawww)
)])

invisible(lsd[, `:=`(
    minacctcanceltime = NULL,
    rats_1mratwwwww = as.numeric(rats_1mratwwwww),
    maxacctcanceltime = NULL,
    rats_1mrathwwww = as.numeric(rats_1mrathwwww),
    rats_1mratawwww = as.numeric(rats_1mratawwww)
)])

invisible(pbi[, `:=`(
    gender = ifelse(pbd1_pbigender == '男性', 0, ifelse(pbd1_pbigender == '女性', 1, NA)),
    diploma_missing = ifelse(pbd1_pbidiploma == '999999972', 1, 0),
    diploma_low = ifelse(pbd1_pbidiploma %in% c('文盲或半文盲', '小学', '初中', '技术学校', '中等专业学校或中等技术学校', '高中'), 1, 0),
    diploma_mid = ifelse(pbd1_pbidiploma %in% c('大学专科和专科学校（简称"大专"）'), 1, 0),
    diploma_high = ifelse(pbd1_pbidiploma %in% c('大学本科（简称"大学"）', '研究生'), 1, 0),

    stu_mrg_widow = ifelse(pbd1_pbistu_mrg == '丧偶', 1, 0),
    stu_mrg_married = ifelse(pbd1_pbistu_mrg == '已婚', 1, 0),
    stu_mrg_single = ifelse(pbd1_pbistu_mrg == '未婚', 1, 0),
    stu_mrg_divorce = ifelse(pbd1_pbistu_mrg == '离婚', 1, 0),
    stu_mrg_missing = ifelse(pbd1_pbistu_mrg == '999999972', 1, 0),

    pbc1_phrtyper_stslast_1 = ifelse(pbc1_phrtyper_stslast == '终止缴费', 1, 0),
    pbc1_phrtyper_stslast_2 = ifelse(pbc1_phrtyper_stslast == '暂停缴费(中断)', 1, 0),
    pbc1_phrtyper_stslast_3 = ifelse(pbc1_phrtyper_stslast == '参保缴费', 1, 0),
    pbc1_phrtyper_stslast_null = ifelse(pbc1_phrtyper_stslast == '999999972', 1, 0),

    pbc1_phrtypeh_sts_1 = ifelse(pbc1_phrtypeh_sts == '缴交', 1, 0),
    pbc1_phrtypeh_sts_2 = ifelse(pbc1_phrtypeh_sts == '封存', 1, 0),
    pbc1_phrtypeh_sts_3 = ifelse(pbc1_phrtypeh_sts == '销户', 1, 0),
    pbc1_phrtypeh_sts_null = ifelse(pbc1_phrtypeh_sts == '999999972', 1, 0)
)])

invisible(pbi[, `:=`(
    pbd1_pbicer_gender = NULL,
    pbc1_pbicer_spogender = NULL,
    pbd0_pbicer_dob = NULL,
    pbd1_phrtimer_emp = NULL,
    pbc1_phrtimer_pay = NULL,
    pbc1_pbicer_spodob = NULL,
    pbc1_phrtimeh_fstp = NULL,
    pbc1_pcdstu_lastcase = NULL,
    pbd1_pbistu_mrg = NULL,
    pbc1_phrtimeh_lstp = NULL,
    pbd1_pbidegree = NULL,
    pbc1_phrtimeh_hf = NULL,
    pbc1_plistu_last = NULL,
    pbd1_pbitype_cer = NULL,
    pbd1_pbidiploma = NULL,
    pbc1_phrtyper_stslast = NULL,
    pbc1_pidrsn_maxrsn = NULL,
    pbd1_phrrsnr_ss = NULL,
    pbc1_pbiif_spo = as.numeric(pbc1_pbiif_spo),
    pbc1_phrtypeh_sts = NULL,
    pbd1_pbidob = NULL,
    pbc1_pcdtype_lastcloway = NULL,
    pbd1_pbigender = NULL
)])

invisible(int[, `:=`(
    ratt_1mwrtwwww = as.numeric(ratt_1mwrtwwww)
)])

save(master_table, lld, lcd, lsd, int, pbi,
     file = "data/all_data.rda",
     compress = FALSE)

file.remove("all_data.rda")


