library(data.table)
load("data/all_data.rda")

train <- master_table[!is.na(fpd) & !is.na(spd) & !is.na(tpd), .(
    id_unqf, fpd, spd, tpd, appl_tm
)][substr(appl_tm, 1, 7) <= '2017-05', .(
    id_unqf,
    target = ifelse(pmax(fpd, spd, tpd) < 10, 'Good',
                    ifelse(pmax(fpd, spd, tpd) >= 30, 'Bad', 'Indeterminate'))
    # appl_mon = substr(appl_tm, 1, 7)
)][target != 'Indeterminate']

test1 <- master_table[!is.na(fpd) & !is.na(spd) & !is.na(tpd), .(
    id_unqf, fpd, spd, tpd, appl_tm
)][substr(appl_tm, 1, 7) == '2017-06', .(
    id_unqf,
    target = ifelse(pmax(fpd, spd, tpd) < 10, 'Good',
                    ifelse(pmax(fpd, spd, tpd) >= 30, 'Bad', 'Indeterminate'))
)][target != 'Indeterminate']

test2 <- master_table[!is.na(fpd) & !is.na(spd) & !is.na(tpd), .(
    id_unqf, fpd, spd, tpd, appl_tm
)][substr(appl_tm, 1, 7) == '2017-07', .(
    id_unqf,
    target = ifelse(pmax(fpd, spd, tpd) < 10, 'Good',
                    ifelse(pmax(fpd, spd, tpd) >= 30, 'Bad', 'Indeterminate'))
)][target != 'Indeterminate']

remove(master_table); invisible(gc())

train <- merge(train, lcd, by = 'id_unqf')
train <- merge(train, lld, by = 'id_unqf')
train <- merge(train, lsd, by = 'id_unqf')
train <- merge(train, pbi, by = 'id_unqf')
train <- merge(train, int, by = 'id_unqf')

test1 <- merge(test1, lcd, by = 'id_unqf')
test1 <- merge(test1, lld, by = 'id_unqf')
test1 <- merge(test1, lsd, by = 'id_unqf')
test1 <- merge(test1, pbi, by = 'id_unqf')
test1 <- merge(test1, int, by = 'id_unqf')

test2 <- merge(test2, lcd, by = 'id_unqf')
test2 <- merge(test2, lld, by = 'id_unqf')
test2 <- merge(test2, lsd, by = 'id_unqf')
test2 <- merge(test2, pbi, by = 'id_unqf')
test2 <- merge(test2, int, by = 'id_unqf')

cols <- colnames(train)
test1 <- test1[, cols, with = FALSE]
test2 <- test2[, cols, with = FALSE]

## remove clients with weak pboc information
train <- train[numl_3ltmtiw < 999999000 | varsmaxcdiffreptmandisstminhistory < 999999000]
test1 <- test1[numl_3ltmtiw < 999999000 | varsmaxcdiffreptmandisstminhistory < 999999000]
test2 <- test2[numl_3ltmtiw < 999999000 | varsmaxcdiffreptmandisstminhistory < 999999000]

saveRDS(train, file = 'data/train.rds')
saveRDS(test1, file = 'data/test1.rds')
saveRDS(test2, file = 'data/test2.rds')

file.remove("data/all_data.rda")
