library(xgboost)
library(ROCR)
library(data.table)
library(ggplot2)
library(rPSI)

# No resampling
train <- readRDS('data/train.rds')
invisible(train[, id_unqf := NULL])
invisible(train[, target := ifelse(target == 'Bad', 1, 0)])
for (col in colnames(train)[-1]) {
    code <- sprintf("invisible(train[, %s := ifelse(%s >= 999999000, NA, %s)])",
                    col, col, col)
    eval(parse(text = code))
}

test1 <- readRDS('data/test1.rds')
invisible(test1[, id_unqf := NULL])
invisible(test1[, target := ifelse(target == 'Bad', 1, 0)])
for (col in colnames(test1)[-1]) {
    code <- sprintf("invisible(test1[, %s := ifelse(%s >= 999999000, NA, %s)])",
                    col, col, col)
    eval(parse(text = code))
}

test2 <- readRDS('data/test2.rds')
invisible(test2[, id_unqf := NULL])
invisible(test2[, target := ifelse(target == 'Bad', 1, 0)])
for (col in colnames(test2)[-1]) {
    code <- sprintf("invisible(test2[, %s := ifelse(%s >= 999999000, NA, %s)])",
                    col, col, col)
    eval(parse(text = code))
}

load('data/pboc_generic_model_objects.rda')

perf <- function(prediction, truth) {
    pred <- ROCR::prediction(prediction, truth)
    auc <- ROCR::performance(pred, 'auc')@y.values[[1]]
    f_dist <- ecdf(prediction[truth == 0])
    t_dist <- ecdf(prediction[truth == 1])
    x <- 0:1000 / 1000
    ks <- max(f_dist(x) - t_dist(x))

    list(auc = auc, ks = ks)
}

train_prediction <- predict(xg.model, as.matrix(train[, pboc_generic_vars, with = FALSE]))
perf(train_prediction, train$target)
test1_prediction <- predict(xg.model, as.matrix(test1[, pboc_generic_vars, with = FALSE]))
perf(test1_prediction, test1$target)
test2_prediction <- predict(xg.model, as.matrix(test2[, pboc_generic_vars, with = FALSE]))
perf(test2_prediction, test2$target)

roc <- function(prediction, truth, tag) {
    pred <- ROCR::prediction(prediction, truth)
    roc_data <- ROCR::performance(pred, 'tpr', 'fpr')
    data.frame(
        tpr = roc_data@y.values[[1]],
        fpr = roc_data@x.values[[1]],
        tag = tag
    )
}

roc_plot_data <- rbind(
    roc(train_prediction, train$target, 'train'),
    roc(test1_prediction, test1$target, 'test1'),
    roc(test2_prediction, test2$target, 'test2')
)

ggplot(roc_plot_data, aes(x = fpr, y = tpr, group = tag, color = tag)) +
    geom_line(size = 0.5) +
    labs(title = "ROC Curves",
         x = 'False Positive Rate',
         y = 'True Positive Rate')

lorenz <- function(prediction, truth) {
    bad_dist <- ecdf(prediction[truth == 1])
    pop_dist <- ecdf(prediction)
    x <- 0:1000/1000
    data.frame(
        pop = pop_dist(x),
        bad = bad_dist(x)
    )
}

lorenz_data <- lorenz(test1_prediction, test1$target)

ggplot(lorenz_data, aes(x = pop, y = bad)) +
    geom_line(size = 0.5) +
    labs(title = "Lorenz Curves",
         x = 'Population Distribution',
         y = 'Bad Distribution')


summary(psi(train_prediction, test1_prediction, cut.levels = 10))
summary(psi(test1_prediction, test2_prediction, cut.levels = 10))
