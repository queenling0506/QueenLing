library(RODBC)
library(magrittr)
library(data.table)

cnx <- odbcConnect('impalaodbc')

master_table <- sqlQuery(cnx, 'select * from risk_analysis.tmp_pboc_generic_model_master_siyuan order by appl_no',
                         as.is = TRUE, stringsAsFactors = FALSE)
master_table <- data.table(master_table)

lcd <- sqlQuery(cnx, 'select * from risk_analysis.tmp_pboc_generic_model_lcd',
                as.is = TRUE,
                stringsAsFactors = FALSE)
lcd <- data.table(lcd)

lld <- sqlQuery(cnx, 'select * from risk_analysis.tmp_pboc_generic_model_lld',
                as.is = TRUE,
                stringsAsFactors = FALSE)
lld <- data.table(lld)

pbi <- sqlQuery(cnx, 'select * from risk_analysis.tmp_pboc_generic_model_pbi',
                as.is = TRUE,
                stringsAsFactors = FALSE)
pbi <- data.table(pbi)

lsd <- sqlQuery(cnx, 'select * from risk_analysis.tmp_pboc_generic_model_lsd',
                as.is = TRUE,
                stringsAsFactors = FALSE)
lsd <- data.table(lsd)

int <- sqlQuery(cnx, 'select * from risk_analysis.tmp_pboc_generic_model_int',
                as.is = TRUE,
                stringsAsFactors = FALSE)
int <- data.table(int)

close(cnx)

save(master_table, lcd, lld, lsd, pbi, int,
     file = 'all_data.rda',
     compress = FALSE)


